/*
 * Name: Kai-Zhan Lee UNI: kl2792 GUI Assignment
 */

import javax.swing.*;

import java.awt.*;

/**
 * This component has 5 equally spaced vertical lines and 5 equally spaced
 * horizontal lines, making a grid. These lines cover the entire frame. The
 * vertical lines alternate blue, green, blue, green, blue, and the horizontal
 * lines alternate red, yellow, red, yellow, red.
 * 
 * @author Kai-Zhan Lee
 * 
 */
public class MyComponent extends JComponent {

	private static final long serialVersionUID = 7467018618855750119L;

	public MyComponent() {
		setPreferredSize(new Dimension(50, 50));
	}

	public void paintComponent(Graphics g) {
		setPreferredSize(new Dimension(getSize().width, getSize().height));
		int height = getSize().height;
		int width = getSize().width;
		boolean isBlue = true;
		// Draw vertical lines
		for (int i = 1; i < 6; i++) {
			if (isBlue)
				g.setColor(Color.BLUE);
			else
				g.setColor(Color.GREEN);
			isBlue = !isBlue;
			g.drawLine((int) (i * (double) width / 6), 0,
					(int) (i * (double) width / 6), height);
		}
		boolean isRed = true;
		// Draw horizontal lines.
		for (int i = 1; i < 6; i++) {
			if (isRed)
				g.setColor(Color.RED);
			else
				g.setColor(Color.YELLOW);
			isRed = !isRed;
			g.drawLine(0, (int) (i * (double) height / 6),
					width, (int) (i * (double) height / 6));
		}
	}
}
