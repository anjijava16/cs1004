
package shapes.d3;

import shapes.Shape;

public abstract class ThreeD implements Shape {
  public final int getDimensions() {
    return 3;
  }
}
