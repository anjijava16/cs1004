
package shapes;

public interface Point {
  int getDimension();
}
