
package shapes;

public interface Centered {
  Point getCenter();
}
