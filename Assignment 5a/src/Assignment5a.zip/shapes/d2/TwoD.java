
package shapes.d2;



import shapes.Shape;



public abstract class TwoD implements Shape {


  public final int getDimensions() {

    return 2;

  }


}

